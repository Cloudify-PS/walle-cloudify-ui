hello-world blueprint
=====================

Cloudify's hello-world blueprint creates a VM on OpenStack and starts an HTTP server using a bash script.

