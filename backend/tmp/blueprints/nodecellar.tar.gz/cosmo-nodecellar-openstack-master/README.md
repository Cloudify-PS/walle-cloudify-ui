cosmo-nodecellar-openstack
==========================

A sample Cloudify 3 application consisted of a nodejs server and mongodb database. 
