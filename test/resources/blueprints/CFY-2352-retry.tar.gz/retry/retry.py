from cloudify import ctx
from cloudify.state import ctx_parameters as inputs

retry_after = inputs.retry_after

ctx.operation.retry(message='TESTING 123', 
				    retry_after=retry_after)
